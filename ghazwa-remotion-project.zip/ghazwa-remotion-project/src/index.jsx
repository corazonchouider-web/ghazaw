import React from "react";
import {
  AbsoluteFill,
  Composition,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
  registerRoot,
} from "remotion";

const GOLD = "#c9a56a";
const WHITE = "#f3f0e9";
const MUTED = "#9a9da4";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" };

const Grain = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        opacity: 0.12,
        backgroundImage:
          "repeating-linear-gradient(0deg, transparent 0px, rgba(255,255,255,.12) 1px, transparent 2px, transparent 4px)",
        transform: `translateY(${frame % 4}px)`,
        pointerEvents: "none",
      }}
    />
  );
};

const Shirt = ({ frame }) => {
  const appear = spring({
    frame: frame - 72,
    fps: 30,
    config: { damping: 16, stiffness: 55 },
  });
  const rotate = interpolate(frame, [70, 180], [-7, 2], clamp);
  const float = Math.sin(frame / 18) * 9;

  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: "46%",
        width: 610,
        height: 690,
        opacity: interpolate(frame, [65, 90], [0, 1], clamp),
        transform: `translate(-50%, -50%) translateY(${(1 - appear) * 100 + float}px) rotate(${rotate}deg) scale(${0.9 + appear * 0.1})`,
        filter: "drop-shadow(0 35px 45px rgba(0,0,0,.65))",
      }}
    >
      <svg viewBox="0 0 600 680" width="100%" height="100%">
        <defs>
          <linearGradient id="fabric" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#34383e" />
            <stop offset="45%" stopColor="#171a1f" />
            <stop offset="100%" stopColor="#090b0e" />
          </linearGradient>
          <linearGradient id="shine" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#fff" stopOpacity="0" />
            <stop offset="48%" stopColor="#fff" stopOpacity=".12" />
            <stop offset="100%" stopColor="#fff" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M190 65 L245 35 Q300 85 355 35 L410 65 L555 155 L490 275 L425 245 L425 635 Q300 660 175 635 L175 245 L110 275 L45 155 Z"
          fill="url(#fabric)"
          stroke="#555a62"
          strokeWidth="3"
        />
        <path d="M245 35 Q300 125 355 35" fill="none" stroke="#62666d" strokeWidth="5" />
        <path d="M178 245 L178 625 M422 245 L422 625" stroke="#777b82" strokeOpacity=".2" strokeWidth="3" />
        <path d="M90 160 L170 260 L170 610" fill="none" stroke="url(#shine)" strokeWidth="28" />
        <path d="M510 160 L430 260 L430 610" fill="none" stroke="url(#shine)" strokeWidth="22" />
        <text x="300" y="350" fill="#e9e5dc" textAnchor="middle" fontSize="37" fontWeight="700" letterSpacing="9">GHAZWA</text>
        <path d="M245 373 H355" stroke={GOLD} strokeWidth="2" />
        <text x="300" y="402" fill="#aaa49a" textAnchor="middle" fontSize="12" letterSpacing="5">EST. ORIGINAL</text>
      </svg>
    </div>
  );
};

const GhazwaAd = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const intro = spring({ frame, fps, config: { damping: 18, stiffness: 65 } });
  const logoOpacity = interpolate(frame, [0, 22, 72, 95], [0, 1, 1, 0], clamp);
  const productOpacity = interpolate(frame, [75, 105, 205, 235], [0, 1, 1, 0], clamp);
  const endOpacity = interpolate(frame, [238, 270, 300], [0, 1, 1], clamp);
  const lineWidth = interpolate(frame, [35, 85], [0, 540], clamp);
  const lightX = interpolate(frame, [0, 300], [-900, 1200], clamp);

  return (
    <AbsoluteFill style={{ backgroundColor: "#080a0d", color: WHITE, fontFamily: "Arial, Helvetica, sans-serif", overflow: "hidden" }}>
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse at 50% 43%, #252a31 0%, #12161c 42%, #07090c 78%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: -300,
          width: 500,
          background: "linear-gradient(90deg, transparent, rgba(201,165,106,.10), transparent)",
          transform: `translateX(${lightX}px) rotate(18deg)`,
          filter: "blur(35px)",
        }}
      />

      <div style={{ position: "absolute", top: 88, width: "100%", textAlign: "center", opacity: logoOpacity, letterSpacing: 10, fontSize: 21, color: "#c7c4bd" }}>
        GHΛZWΛ
      </div>

      <div style={{ position: "absolute", top: "32%", width: "100%", textAlign: "center", opacity: logoOpacity, transform: `translateY(${(1 - intro) * 55}px)` }}>
        <div style={{ fontSize: 104, fontWeight: 900, letterSpacing: 8, lineHeight: 1 }}>GHAZWA</div>
        <div style={{ marginTop: 25, fontSize: 17, letterSpacing: 7, color: MUTED }}>WEAR YOUR PRESENCE</div>
      </div>

      <div style={{ position: "absolute", top: "49%", left: "50%", height: 2, width: lineWidth, transform: "translateX(-50%)", background: `linear-gradient(90deg, transparent, ${GOLD}, transparent)` }} />

      <Shirt frame={frame} />

      <div style={{ position: "absolute", bottom: 220, width: "100%", textAlign: "center", opacity: productOpacity }}>
        <div style={{ fontSize: 24, fontWeight: 700, letterSpacing: 5 }}>THE OVERSIZED DROP</div>
        <div style={{ marginTop: 18, fontSize: 14, letterSpacing: 5, color: GOLD }}>FORM  •  FIT  •  IDENTITY</div>
      </div>

      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", background: "#080a0d", opacity: endOpacity }}>
        <div style={{ fontSize: 96, fontWeight: 900, letterSpacing: 8 }}>GHAZWA</div>
        <div style={{ width: 110, height: 2, background: GOLD, marginTop: 30 }} />
        <div style={{ marginTop: 27, color: MUTED, fontSize: 16, letterSpacing: 7 }}>CREATED TO BE DIFFERENT</div>
        <div style={{ position: "absolute", bottom: 125, fontSize: 13, letterSpacing: 5, color: "#777b82" }}>YOUR PRESENCE. YOUR STORY.</div>
      </AbsoluteFill>

      <Grain />
      <div style={{ position: "absolute", bottom: 55, width: "100%", textAlign: "center", fontSize: 11, letterSpacing: 5, color: "#666b73" }}>
        GHAZWA  /  OFFICIAL CAMPAIGN
      </div>
    </AbsoluteFill>
  );
};

const Root = () => (
  <Composition
    id="GhazwaAd"
    component={GhazwaAd}
    durationInFrames={300}
    fps={30}
    width={1080}
    height={1920}
  />
);

registerRoot(Root);
