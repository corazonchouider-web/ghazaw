# GHAZWA — Remotion Ad

A 10-second vertical 1080×1920 motion-graphics advertisement for the GHAZWA brand.

## Run locally

1. Install Node.js (18 or newer).
2. Open this folder in a terminal.
3. Run `npm install`.
4. Preview with `npm run preview`.
5. Render the MP4 with `npm run render`.

The rendered video will be saved to `out/ghazwa-ad.mp4`.

## Project structure

- `package.json` — dependencies and commands
- `src/index.jsx` — Remotion composition
- `out/` — output folder
